# TR-D06 R03 Payments & Wallet: frontend test guide

Setup: backend running with RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET (test keys) and RAZORPAY_WEBHOOK_SECRET; `npm run dev` in frontend; log in as a customer.

Razorpay test data
- Card: 4111 1111 1111 1111, any future expiry, any CVV, OTP 1234 (success)
- UPI: success@razorpay (pays) / failure@razorpay (fails)
- Netbanking / wallet: choose the test bank/wallet, then Success or Failure on the mock page

Checks
1. Success: book a service, pick UPI/card, pay -> processing -> success page; booking CONFIRMED; row appears on /customer/payments as Paid with receipt.
2. Failed: pay with failure@razorpay -> "Payment failed" + retry; booking stays pending.
3. Cancelled: close the Razorpay popup -> "Payment cancelled" + retry; no charge.
4. Retry: after 2 or 3, retry and pay successfully.
5. Cash on service: booking CONFIRMED, payment Pending, receipt column shows "On service".
6. Double click: double-click Pay quickly -> one popup, one order.
7. Duplicate payment: after success, go back and try to pay the same booking -> blocked, no second charge.
8. Payments list: filter each status, page through, open Receipt, click the booking link.
9. Wallet: balance + history, filter by credit/debit/refund/referral.
10. States: new customer -> empty; stop backend -> error + Retry; DevTools Offline -> offline state, no blank screen.
11. Responsive: 360 / 768 / 1280 px, no horizontal scroll (table becomes cards below md).
12. Keyboard: Tab through method cards (arrow keys switch), Pay, filters, pagination; focus ring always visible.
13. Build/lint: `npm run build`; `npx eslint src --ext ts,tsx` (needs eslint-plugin-react-hooks installed); console shows no errors.
