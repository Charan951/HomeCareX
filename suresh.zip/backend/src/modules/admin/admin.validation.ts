export const adminValidation = {};
