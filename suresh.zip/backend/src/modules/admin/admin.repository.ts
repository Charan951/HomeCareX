export class AdminRepository {}
