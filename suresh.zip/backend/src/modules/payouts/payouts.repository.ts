export class PayoutsRepository {}
