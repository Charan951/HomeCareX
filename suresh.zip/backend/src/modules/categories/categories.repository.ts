export class CategoriesRepository {}
