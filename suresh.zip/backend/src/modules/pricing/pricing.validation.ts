export const pricingValidation = {};
