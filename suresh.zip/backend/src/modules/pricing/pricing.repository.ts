export class PricingRepository {}
