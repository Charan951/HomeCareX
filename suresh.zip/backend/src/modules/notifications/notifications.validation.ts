export const notificationsValidation = {};
