export class TicketsRepository {}
