export const ticketsValidation = {};
