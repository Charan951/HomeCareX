export const registerBookingSocket = () => {};
