export const registerChatSocket = () => {};
